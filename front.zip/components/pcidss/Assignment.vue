<script setup>
    // const {assignment} = defineProps({
    //     assignment:{
    //         type:Object
    //     }
    // })
</script>

<template>
  <div>
    <h2 class="text-2xl font-bold" ></h2>
    {{ assignment }}
    <div class="">
        <!-- <div class="" style="background-color: teal; padding: 2px">
        {{ defaultValues.descriptionTitle }}
        </div> -->
        <!-- <div class="" v-for="(description, key) in assignment.descriptions">
            <h4 v-html="description.title"></h4>
        </div> -->
    </div>
  </div>
</template>


<style>

</style>
