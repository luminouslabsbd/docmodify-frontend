<template>
  <div>
    <h2 class="text-4xl" >Requirement</h2>
  </div>
</template>

<script lang="ts" setup>

</script>

<style>

</style>
