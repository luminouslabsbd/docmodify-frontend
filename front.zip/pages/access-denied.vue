
<script lang="ts" setup>
    definePageMeta({
        layout:'auth-layout',
    })

    useHead({ title: 'Access Denied' });
</script>

<template>
  <div>
    <h1>Access denied page</h1>
  </div>
</template>


<style>

</style>
