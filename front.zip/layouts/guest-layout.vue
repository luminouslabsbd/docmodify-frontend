<template>
  <div>
    <h1 class="text-2xl">Guest Layout</h1>
    <slot />
  </div>
</template>

<script lang="ts" setup>

</script>

<style>

</style>
